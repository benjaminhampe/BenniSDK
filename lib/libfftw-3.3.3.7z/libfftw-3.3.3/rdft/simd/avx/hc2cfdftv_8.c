/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx.h"
#include "../common/hc2cfdftv_8.c"
