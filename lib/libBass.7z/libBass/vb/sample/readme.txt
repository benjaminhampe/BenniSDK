Simple Test application for BASS_WADSP:
---------------------------------------
provided by : snake@s-n-a-k-e.net !THX!

To let the wadsp.exe run:
a) copy "bass.dll" to this directory
b) copy "bass_wadsp.dll" to this directory
c) copy some Winamp DSP dlls to the "plugins" directory
d) start "wadsp.exe"

To (re)compile the source:
a) copy the "bass.bas" lib file to this directory
b) copy the "bass_wadsp.bas" lib file to this directory
